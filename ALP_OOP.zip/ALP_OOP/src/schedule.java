
import java.util.Date;

public class schedule extends item {

    private Date startTime;
    private Date endTime;

    public schedule(String title, String desc, String category, Date startTime, Date endTime) {
        super(title, desc, category);
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public Date getStartTime() {
        return startTime;
    }

    public Date getEndTime() {
        return endTime;
    }
}
