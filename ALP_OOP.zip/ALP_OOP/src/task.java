
import java.util.Date;

public class task extends item {

    private Date deadline;

    public task(String title, String desc, String category, Date deadline) {
        super(title, desc, category);
        this.deadline = deadline;
    }

    public Date getDeadline() {
        return deadline;
    }

}
