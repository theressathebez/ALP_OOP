
import java.util.ArrayList;
import java.util.Date;


public class manage {
    //list of task
    private ArrayList<task> tasks = new ArrayList<>();
    
    //list of schedule
    private ArrayList<schedule> schedules = new ArrayList<>();

    public manage() {
        tasks = new ArrayList<>();
        schedules = new ArrayList<>();
    }
    
    // create a new task
    public void addTask(String title, String description, String category, Date deadline) {
        task newTask = new task(title, description, category, deadline);
        tasks.add(newTask);
    }

    // create a new schedule
    public void addSchedule(String title, String description, String category, Date startTime, Date endTime) {
        schedule newSchedule = new schedule(title, description, category, startTime, endTime);
        schedules.add(newSchedule);
    }
    
    
}
