
public class Main {
    public static void main(String[] args) {
        appflow menu = new appflow ();
        menu.start();
    }
}
